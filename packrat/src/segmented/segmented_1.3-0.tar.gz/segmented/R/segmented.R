`segmented` <-
function(obj, seg.Z, psi, npsi, fixed.psi=NULL, control=seg.control(), model=TRUE, ...){
            UseMethod("segmented")
            }
